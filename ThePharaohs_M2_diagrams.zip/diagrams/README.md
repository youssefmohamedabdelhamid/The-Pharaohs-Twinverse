# Milestone 2 diagram sources

Put this folder in the repository at `docs/m2/diagrams/`. Each `.mmd` file is the Mermaid source of one figure in the SAD; the `.png` and `.svg` files are renders of it.

| File | Figure |
| --- | --- |
| c4-container.mmd | 3.1 Container view (C4 Level 2) |
| c4-component-core-api.mmd | 3.2 Component view of the Core API (C4 Level 3) |
| seq-1-analysis-progress.mmd | SD-1 Crack analysis with progress (QAS-1) |
| seq-2-worker-failover.mmd | SD-2 Worker crash and recovery (QAS-2) |
| seq-3-report-approval-g3.mmd | SD-3 Gate G3 approval with an unauthorised attempt (QAS-3) |
| seq-4-cited-report.mmd | SD-4 Cite-or-abstain assessment (QAS-7) |
| deployment.mmd | 3.4 Deployment view |
| data-erd.mmd | 3.5 Data view (ERD) |

To re-render a diagram: `npx -p @mermaid-js/mermaid-cli mmdc -i c4-container.mmd -o c4-container.png -s 2 -b white`
